# Definiowanie szczegółowej struktury nowoczesnego frontendu dla open-source-operator
import json

frontend_architecture = {
    "technology_stack": {
        "framework": "Next.js 15",
        "react_version": "React 19",
        "styling": "Tailwind CSS v4",
        "typescript": "TypeScript 5.6+",
        "build_tool": "Turbopack (Vite 6 fallback)",
        "state_management": "Zustand + React Query/TanStack Query",
        "ui_components": "Shadcn/ui + Headless UI",
        "icons": "Lucide React",
        "charts": "Recharts + D3.js",
        "forms": "React Hook Form + Zod",
        "websockets": "Socket.io-client",
        "http_client": "Axios"
    },
    "project_structure": {
        "frontend/": {
            "app/": "Next.js 15 App Router",
            "components/": {
                "ui/": "Podstawowe komponenty UI (shadcn/ui)",
                "dashboard/": "Komponenty dashboardu",
                "agent/": "Komponenty do zarządzania agentami",
                "trajectory/": "Komponenty trajektorii i adnotacji",
                "models/": "Komponenty konfiguracji modeli",
                "monitoring/": "Komponenty monitoringu"
            },
            "lib/": {
                "api.ts": "Klient API do komunikacji z backendem Python",
                "websocket.ts": "Obsługa WebSocket dla real-time",
                "store.ts": "Zustand store",
                "utils.ts": "Funkcje pomocnicze",
                "types.ts": "Definicje typów TypeScript"
            },
            "styles/": "Pliki CSS (Tailwind v4)",
            "public/": "Statyczne zasoby"
        }
    },
    "key_features": {
        "dashboard": {
            "description": "Główny dashboard z przeglądem agentów i sesji",
            "components": ["AgentOverview", "SessionsTable", "PerformanceMetrics", "QuickActions"]
        },
        "agent_management": {
            "description": "Zarządzanie agentami przeglądarkowych",
            "components": ["AgentList", "AgentConfig", "ModelSelector", "AgentLogs"]
        },
        "trajectory_annotation": {
            "description": "Adnotacja i zarządzanie trajektoriami WWW",
            "components": ["TrajectoryViewer", "AnnotationEditor", "SessionReplay", "DataExport"]
        },
        "real_time_monitoring": {
            "description": "Monitoring działania agentów w czasie rzeczywistym",
            "components": ["LiveAgentView", "ConsoleOutput", "PerformanceGraphs", "ErrorTracking"]
        },
        "model_configuration": {
            "description": "Konfiguracja modeli AI (OpenAI, Anthropic, Google)",
            "components": ["ModelSettings", "APIKeyManager", "ProviderSelector", "TestInterface"]
        },
        "data_pipeline": {
            "description": "Pipeline danych i supervised fine-tuning",
            "components": ["DataProcessor", "SFTConfig", "TrainingProgress", "ModelEvaluation"]
        }
    },
    "integration_points": {
        "backend_api": {
            "base_url": "/api",
            "endpoints": {
                "/agents": "CRUD operacje na agentach",
                "/sessions": "Zarządzanie sesjami",
                "/trajectories": "Trajektorie i adnotacje", 
                "/models": "Konfiguracja modeli",
                "/data": "Pipeline danych",
                "/monitoring": "Metryki i monitoring"
            }
        },
        "websocket": {
            "url": "/ws",
            "channels": ["agent_status", "console_output", "performance_metrics"]
        },
        "file_system": {
            "uploads": "/uploads",
            "exports": "/exports",
            "configs": "/configs"
        }
    }
}

# Generowanie pliku JSON z architekturą
with open('frontend_architecture.json', 'w', encoding='utf-8') as f:
    json.dump(frontend_architecture, f, indent=2, ensure_ascii=False)

print("✅ Wygenerowano szczegółową architekturę frontendu")
print("📁 Zapisano do pliku: frontend_architecture.json")
print(f"🔧 Wybrane technologie: {frontend_architecture['technology_stack']['framework']}, {frontend_architecture['technology_stack']['react_version']}")
print(f"💅 Styling: {frontend_architecture['technology_stack']['styling']}")
print(f"📊 Komponenty UI: {frontend_architecture['technology_stack']['ui_components']}")