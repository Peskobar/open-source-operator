
# 🔧 Instrukcja Instalacji i Integracji

## Krok 1: Przygotowanie Środowiska

### 1.1 Klonowanie Repozytorium
```bash
git clone https://github.com/Peskobar/open-source-operator.git
cd open-source-operator
```

### 1.2 Tworzenie Folderu Frontend
```bash
mkdir frontend
cd frontend
```

### 1.3 Pobranie Plików Frontendu
Skopiuj wszystkie pliki z wygenerowanej aplikacji do folderu `frontend/`:
- index.html
- style.css  
- app.js

## Krok 2: Aktualizacja Backend

### 2.1 Instalacja Dodatkowych Zależności
```bash
cd .. # powrót do głównego folderu
pip install fastapi uvicorn websockets python-multipart
```

### 2.2 Modyfikacja inference/app.py

Zastąp istniejący kod Gradio:

```python
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
import json
import asyncio
from typing import List
import os

app = FastAPI(title="Open Source Operator Dashboard")

# Konfiguracja CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serwowanie frontendu
app.mount("/static", StaticFiles(directory="frontend"), name="static")

@app.get("/", response_class=HTMLResponse)
async def root():
    with open("frontend/index.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())

# WebSocket manager dla real-time komunikacji
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: str):
        for connection in self.active_connections:
            try:
                await connection.send_text(message)
            except:
                await self.disconnect(connection)

manager = ConnectionManager()

# API Endpoints
@app.get("/api/agents")
async def get_agents():
    # Integracja z istniejącą logiką agentów
    agents = [
        {
            "id": 1,
            "name": "WebArena Agent",
            "model": "GPT-4",
            "status": "active",
            "sessions": 23,
            "success_rate": 0.87,
            "last_task": "E-commerce navigation",
            "created": "2025-06-15T10:30:00Z"
        }
        # Dodaj więcej agentów z bazy danych
    ]
    return {"agents": agents}

@app.post("/api/agents")
async def create_agent(agent_data: dict):
    # Implementacja tworzenia nowego agenta
    # Integracja z configs/config.yaml
    return {"status": "created", "agent_id": len(agents) + 1}

@app.get("/api/sessions")
async def get_sessions():
    # Pobierz sesje z bazy danych lub plików
    sessions = []
    return {"sessions": sessions}

@app.get("/api/models")
async def get_models():
    # Zwróć dostępne modele AI
    models = [
        {"name": "GPT-4", "provider": "OpenAI", "status": "connected"},
        {"name": "Claude-3", "provider": "Anthropic", "status": "connected"},
        {"name": "Gemini Pro", "provider": "Google", "status": "error"}
    ]
    return {"models": models}

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            # Wysyłaj dane w czasie rzeczywistym
            data = {
                "type": "system_update",
                "timestamp": "2025-06-28T10:25:00Z",
                "metrics": {
                    "active_agents": 3,
                    "cpu_usage": 45,
                    "memory_usage": 67
                }
            }
            await websocket.send_text(json.dumps(data))
            await asyncio.sleep(5)
    except WebSocketDisconnect:
        manager.disconnect(websocket)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=7860)
```

## Krok 3: Konfiguracja Integracji

### 3.1 Aktualizacja main.py

Dodaj funkcje API do istniejącego main.py:

```python
# Dodaj na początku pliku
from fastapi import FastAPI
import sys
import os

# Dodaj funkcje pomocnicze
def get_agent_status():
    """Zwróć status wszystkich agentów"""
    # Integracja z istniejącą logiką
    return []

def get_session_data():
    """Pobierz dane sesji z bazy"""
    # Integracja z data/sft/
    return []

def export_trajectory_data(session_id):
    """Eksportuj dane trajektorii"""
    # Integracja z eksportem danych
    return {}
```

### 3.2 Konfiguracja configs/config.yaml

Dodaj sekcję frontend:

```yaml
# Istniejąca konfiguracja...

frontend:
  enabled: true
  port: 7860
  cors_origins: ["*"]
  websocket_enabled: true

dashboard:
  refresh_interval: 5
  max_sessions_display: 100
  real_time_monitoring: true
```

## Krok 4: Uruchomienie Systemu

### 4.1 Uruchomienie Backend
```bash
# Z głównego folderu projektu
python inference/app.py
```

### 4.2 Dostęp do Dashboardu
Otwórz przeglądarkę i przejdź do:
```
http://localhost:7860
```

### 4.3 Testowanie WebSocket
Dashboard automatycznie połączy się z WebSocket dla real-time updates.

## Krok 5: Integracja z Istniejącymi Funkcjami

### 5.1 Integracja z iMean Builder
```python
# W app.py
@app.post("/api/import/imean")
async def import_imean_data():
    # Użyj istniejącej logiki z main.py
    from main import download_data_from_imean
    result = download_data_from_imean()
    return {"status": "imported", "count": len(result)}
```

### 5.2 Integracja z WebCanvas
```python
@app.get("/api/evaluation/webcanvas")
async def get_webcanvas_results():
    # Integracja z automatyczną ewaluacją
    return {"results": []}
```

### 5.3 Integracja z Supervised Fine-tuning
```python
@app.post("/api/sft/start")
async def start_sft_training(config: dict):
    # Uruchom proces SFT
    return {"status": "started", "job_id": "sft_001"}
```

## Krok 6: Deployment i Produkcja

### 6.1 Docker Setup (opcjonalnie)
```dockerfile
FROM python:3.11

WORKDIR /app
COPY . .
RUN pip install -r requirements.txt

EXPOSE 7860
CMD ["python", "inference/app.py"]
```

### 6.2 Systemd Service (Linux)
```ini
[Unit]
Description=Open Source Operator Dashboard
After=network.target

[Service]
Type=simple
User=operator
WorkingDirectory=/path/to/open-source-operator
ExecStart=/usr/bin/python inference/app.py
Restart=always

[Install]
WantedBy=multi-user.target
```

## Krok 7: Testowanie Integracji

### 7.1 Test API Endpoints
```bash
# Test agentów
curl http://localhost:7860/api/agents

# Test modeli
curl http://localhost:7860/api/models

# Test sesji
curl http://localhost:7860/api/sessions
```

### 7.2 Test WebSocket
```javascript
// W konsoli przeglądarki
const ws = new WebSocket('ws://localhost:7860/ws');
ws.onmessage = (event) => console.log(JSON.parse(event.data));
```

## Krok 8: Migracja Danych

### 8.1 Import Istniejących Sesji
```python
@app.post("/api/migrate/sessions")
async def migrate_existing_sessions():
    # Skanuj data/sft/ i importuj sesje
    import glob
    sessions = []
    for file in glob.glob("data/sft/*.json"):
        # Parsuj i importuj dane
        pass
    return {"migrated": len(sessions)}
```

### 8.2 Import Konfiguracji Agentów
```python
@app.post("/api/migrate/agents")
async def migrate_agent_configs():
    # Import z configs/config.yaml
    return {"status": "migrated"}
```

## Troubleshooting

### Problem: Frontend nie ładuje się
**Rozwiązanie**: Sprawdź czy folder `frontend/` zawiera wszystkie pliki i czy ścieżka w `app.mount()` jest poprawna.

### Problem: WebSocket nie działa
**Rozwiązanie**: Sprawdź czy port 7860 nie jest blokowany przez firewall i czy WebSocket endpoint jest aktywny.

### Problem: API zwraca błędy
**Rozwiązanie**: Sprawdź logi backend'u i upewnij się, że wszystkie dependencje są zainstalowane.

### Problem: Dane nie synchronizują się
**Rozwiązanie**: Sprawdź integrację z istniejącymi plikami danych i bazą SQLite.

## Wsparcie

Jeśli napotkasz problemy z integracją, sprawdź:
1. Logi aplikacji w konsoli
2. Network tab w Developer Tools przeglądarki
3. Czy wszystkie endpointy API odpowiadają poprawnie
4. Czy WebSocket połączenie jest aktywne

Frontend został zaprojektowany jako drop-in replacement dla Gradio z pełną zgodnością wsteczną.
