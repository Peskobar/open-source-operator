// Application Data
const appData = {
  "agents": [
    {"id": 1, "name": "WebArena Agent", "model": "GPT-4", "status": "active", "sessions": 23, "success_rate": 0.87, "last_task": "E-commerce navigation", "created": "2025-06-15T10:30:00Z"},
    {"id": 2, "name": "Form Filler Pro", "model": "Claude-3", "status": "idle", "sessions": 45, "success_rate": 0.92, "last_task": "Job application form", "created": "2025-06-14T09:15:00Z"},
    {"id": 3, "name": "Research Bot", "model": "Gemini Pro", "status": "running", "sessions": 12, "success_rate": 0.78, "last_task": "Academic paper search", "created": "2025-06-13T14:45:00Z"}
  ],
  "sessions": [
    {"id": 101, "agent_id": 1, "task": "Login to banking portal", "status": "completed", "duration": 34, "start_time": "2025-06-28T08:30:00Z", "steps": 12, "success": true},
    {"id": 102, "agent_id": 2, "task": "Fill job application", "status": "failed", "duration": 67, "start_time": "2025-06-28T09:15:00Z", "steps": 8, "success": false, "error": "CAPTCHA not solved"},
    {"id": 103, "agent_id": 1, "task": "Product comparison", "status": "running", "duration": 23, "start_time": "2025-06-28T10:00:00Z", "steps": 6, "success": null}
  ],
  "models": [
    {"name": "GPT-4", "provider": "OpenAI", "status": "connected", "cost_per_1k": 0.03, "avg_response_time": 1.2, "success_rate": 0.89},
    {"name": "Claude-3", "provider": "Anthropic", "status": "connected", "cost_per_1k": 0.025, "avg_response_time": 1.4, "success_rate": 0.91},
    {"name": "Gemini Pro", "provider": "Google", "status": "error", "cost_per_1k": 0.02, "avg_response_time": 0.9, "success_rate": 0.85},
    {"name": "DeepSeek", "provider": "DeepSeek", "status": "connected", "cost_per_1k": 0.001, "avg_response_time": 2.1, "success_rate": 0.76}
  ],
  "metrics": {
    "total_sessions": 156,
    "active_agents": 3,
    "success_rate": 0.84,
    "avg_task_duration": 42,
    "daily_stats": [
      {"date": "2025-06-23", "sessions": 12, "success": 10},
      {"date": "2025-06-24", "sessions": 15, "success": 13},
      {"date": "2025-06-25", "sessions": 18, "success": 16},
      {"date": "2025-06-26", "sessions": 22, "success": 19},
      {"date": "2025-06-27", "sessions": 19, "success": 17},
      {"date": "2025-06-28", "sessions": 8, "success": 7}
    ]
  },
  "system_status": {
    "uptime": "5 days, 12 hours",
    "cpu_usage": 23,
    "memory_usage": 67,
    "disk_usage": 45,
    "network_activity": "normal"
  }
};

// Application State
let currentSection = 'dashboard';
let sidebarCollapsed = false;
let isDarkMode = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;

// DOM Elements
const sidebar = document.getElementById('sidebar');
const sidebarToggle = document.getElementById('sidebarToggle');
const menuToggle = document.getElementById('menuToggle');
const themeToggle = document.getElementById('themeToggle');
const breadcrumbText = document.getElementById('breadcrumbText');
const agentModal = document.getElementById('agentModal');
const closeModal = document.getElementById('closeModal');
const cancelAgent = document.getElementById('cancelAgent');
const saveAgent = document.getElementById('saveAgent');

// Initialize Application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    renderDashboard();
    renderAgents();
    renderSessions();
    renderMonitoring();
    renderModels();
    initializeChart();
});

function initializeApp() {
    // Check for saved theme preference or use system preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        isDarkMode = savedTheme === 'dark';
    }
    updateTheme();
    
    // Update metrics in header
    updateMetrics();
}

function setupEventListeners() {
    // Sidebar navigation
    document.querySelectorAll('.sidebar__item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.getAttribute('data-section');
            navigateToSection(section);
        });
    });

    // Theme toggle
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }

    // Sidebar toggle
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', toggleSidebar);
    }
    if (menuToggle) {
        menuToggle.addEventListener('click', toggleMobileSidebar);
    }

    // Modal events
    if (closeModal) {
        closeModal.addEventListener('click', closeAgentModal);
    }
    if (cancelAgent) {
        cancelAgent.addEventListener('click', closeAgentModal);
    }
    if (saveAgent) {
        saveAgent.addEventListener('click', saveNewAgent);
    }

    // Close modal on overlay click
    if (agentModal) {
        agentModal.addEventListener('click', (e) => {
            if (e.target === agentModal) {
                closeAgentModal();
            }
        });
    }

    // Handle escape key for modal
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && agentModal && agentModal.classList.contains('active')) {
            closeAgentModal();
        }
    });

    // Dashboard "Nowy Agent" button
    document.addEventListener('click', (e) => {
        if (e.target.textContent === 'Nowy Agent' || e.target.textContent === 'Dodaj Agenta') {
            openAgentModal();
        }
    });
}

function navigateToSection(section) {
    // Update active sidebar item
    document.querySelectorAll('.sidebar__item').forEach(item => {
        item.classList.remove('active');
    });
    const activeItem = document.querySelector(`[data-section="${section}"]`);
    if (activeItem) {
        activeItem.classList.add('active');
    }

    // Update active content section
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    const activeSection = document.getElementById(`${section}-section`);
    if (activeSection) {
        activeSection.classList.add('active');
    }

    // Update breadcrumb
    const sectionNames = {
        dashboard: 'Dashboard',
        agents: 'Zarządzanie Agentami',
        sessions: 'Historie Sesji',
        monitoring: 'Monitoring w Czasie Rzeczywistym',
        models: 'Konfiguracja Modeli AI',
        pipeline: 'Pipeline Przetwarzania Danych'
    };
    if (breadcrumbText) {
        breadcrumbText.textContent = sectionNames[section] || 'Dashboard';
    }

    currentSection = section;
}

function toggleTheme() {
    isDarkMode = !isDarkMode;
    updateTheme();
    localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
}

function updateTheme() {
    const root = document.documentElement;
    if (isDarkMode) {
        root.setAttribute('data-color-scheme', 'dark');
        if (themeToggle) {
            themeToggle.textContent = '☀️';
        }
    } else {
        root.setAttribute('data-color-scheme', 'light');
        if (themeToggle) {
            themeToggle.textContent = '🌙';
        }
    }
}

function toggleSidebar() {
    sidebarCollapsed = !sidebarCollapsed;
    if (sidebar) {
        sidebar.classList.toggle('collapsed', sidebarCollapsed);
    }
}

function toggleMobileSidebar() {
    if (sidebar) {
        sidebar.classList.toggle('mobile-open');
    }
}

function updateMetrics() {
    const activeAgentsEl = document.getElementById('activeAgents');
    const totalSessionsEl = document.getElementById('totalSessions');
    const successRateEl = document.getElementById('successRate');
    const avgDurationEl = document.getElementById('avgDuration');

    if (activeAgentsEl) activeAgentsEl.textContent = appData.metrics.active_agents;
    if (totalSessionsEl) totalSessionsEl.textContent = appData.metrics.total_sessions;
    if (successRateEl) successRateEl.textContent = Math.round(appData.metrics.success_rate * 100) + '%';
    if (avgDurationEl) avgDurationEl.textContent = appData.metrics.avg_task_duration + 's';
}

function renderDashboard() {
    renderRecentTasks();
}

function renderRecentTasks() {
    const tasksContainer = document.getElementById('recentTasks');
    if (!tasksContainer) return;

    const recentSessions = appData.sessions.slice(0, 5);

    tasksContainer.innerHTML = recentSessions.map(session => {
        const agent = appData.agents.find(a => a.id === session.agent_id);
        const statusClass = session.status === 'completed' ? 'success' : 
                           session.status === 'failed' ? 'error' : 'warning';
        const statusText = session.status === 'completed' ? 'Zakończone' :
                          session.status === 'failed' ? 'Błąd' : 'W toku';

        return `
            <div class="task-item">
                <div class="task-info">
                    <h4 class="task-name">${session.task}</h4>
                    <p class="task-meta">Agent: ${agent ? agent.name : 'Unknown'} • ${formatTime(session.start_time)}</p>
                </div>
                <div class="status status--${statusClass}">${statusText}</div>
            </div>
        `;
    }).join('');
}

function renderAgents() {
    const agentsGrid = document.getElementById('agentsGrid');
    if (!agentsGrid) return;
    
    agentsGrid.innerHTML = appData.agents.map(agent => {
        const statusClass = agent.status === 'active' ? 'success' : 
                           agent.status === 'idle' ? 'warning' : 'info';
        const statusText = agent.status === 'active' ? 'Aktywny' :
                          agent.status === 'idle' ? 'Bezczynny' : 'Działający';

        return `
            <div class="agent-card">
                <div class="agent-card__header">
                    <h3 class="agent-card__title">${agent.name}</h3>
                    <div class="status status--${statusClass}">${statusText}</div>
                </div>
                <div class="agent-card__body">
                    <div class="agent-meta">
                        <div class="agent-meta-item">
                            <span class="agent-meta-label">Model:</span>
                            <span class="agent-meta-value">${agent.model}</span>
                        </div>
                        <div class="agent-meta-item">
                            <span class="agent-meta-label">Sesje:</span>
                            <span class="agent-meta-value">${agent.sessions}</span>
                        </div>
                        <div class="agent-meta-item">
                            <span class="agent-meta-label">Sukces:</span>
                            <span class="agent-meta-value">${Math.round(agent.success_rate * 100)}%</span>
                        </div>
                        <div class="agent-meta-item">
                            <span class="agent-meta-label">Ostatnie zadanie:</span>
                            <span class="agent-meta-value">${agent.last_task}</span>
                        </div>
                    </div>
                    <div class="agent-actions">
                        <button class="btn btn--outline btn--sm" onclick="viewAgentLogs(${agent.id})">Logi</button>
                        <button class="btn btn--primary btn--sm" onclick="configureAgent(${agent.id})">Konfiguruj</button>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

function renderSessions() {
    const sessionsTable = document.getElementById('sessionsTable');
    if (!sessionsTable) return;
    
    const tableHTML = `
        <table class="sessions-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Zadanie</th>
                    <th>Agent</th>
                    <th>Status</th>
                    <th>Czas trwania</th>
                    <th>Kroki</th>
                    <th>Rozpoczęcie</th>
                </tr>
            </thead>
            <tbody>
                ${appData.sessions.map(session => {
                    const agent = appData.agents.find(a => a.id === session.agent_id);
                    const statusClass = session.status === 'completed' ? 'success' : 
                                       session.status === 'failed' ? 'error' : 'warning';
                    const statusText = session.status === 'completed' ? 'Zakończone' :
                                      session.status === 'failed' ? 'Błąd' : 'W toku';

                    return `
                        <tr onclick="viewSessionDetails(${session.id})" style="cursor: pointer;">
                            <td>${session.id}</td>
                            <td>${session.task}</td>
                            <td>${agent ? agent.name : 'Unknown'}</td>
                            <td><span class="status status--${statusClass}">${statusText}</span></td>
                            <td>${session.duration}s</td>
                            <td>${session.steps}</td>
                            <td>${formatDate(session.start_time)}</td>
                        </tr>
                    `;
                }).join('')}
            </tbody>
        </table>
    `;
    
    sessionsTable.innerHTML = tableHTML;
}

function renderMonitoring() {
    renderSystemStatus();
    renderResourceMetrics();
}

function renderSystemStatus() {
    const systemStatus = document.getElementById('systemStatus');
    if (!systemStatus) return;

    const status = appData.system_status;
    
    systemStatus.innerHTML = `
        <div class="status-item">
            <span class="status-label">Czas działania:</span>
            <span class="status-value">${status.uptime}</span>
        </div>
        <div class="status-item">
            <span class="status-label">Aktywność sieci:</span>
            <span class="status-value">${status.network_activity}</span>
        </div>
        <div class="status-item">
            <span class="status-label">Ostatnia aktualizacja:</span>
            <span class="status-value">2 minuty temu</span>
        </div>
    `;
}

function renderResourceMetrics() {
    const resourceMetrics = document.getElementById('resourceMetrics');
    if (!resourceMetrics) return;

    const status = appData.system_status;
    
    resourceMetrics.innerHTML = `
        <div class="resource-item">
            <div class="resource-label">
                <span>CPU</span>
                <span>${status.cpu_usage}%</span>
            </div>
            <div class="resource-bar">
                <div class="resource-fill" style="width: ${status.cpu_usage}%"></div>
            </div>
        </div>
        <div class="resource-item">
            <div class="resource-label">
                <span>Pamięć</span>
                <span>${status.memory_usage}%</span>
            </div>
            <div class="resource-bar">
                <div class="resource-fill" style="width: ${status.memory_usage}%"></div>
            </div>
        </div>
        <div class="resource-item">
            <div class="resource-label">
                <span>Dysk</span>
                <span>${status.disk_usage}%</span>
            </div>
            <div class="resource-bar">
                <div class="resource-fill" style="width: ${status.disk_usage}%"></div>
            </div>
        </div>
    `;
}

function renderModels() {
    const modelsGrid = document.getElementById('modelsGrid');
    if (!modelsGrid) return;
    
    modelsGrid.innerHTML = appData.models.map(model => {
        const statusClass = model.status === 'connected' ? 'success' : 'error';
        const statusText = model.status === 'connected' ? 'Połączony' : 'Błąd';

        return `
            <div class="model-card">
                <div class="model-header">
                    <div>
                        <h3 class="model-name">${model.name}</h3>
                        <p class="model-provider">${model.provider}</p>
                    </div>
                    <div class="status status--${statusClass}">${statusText}</div>
                </div>
                <div class="agent-meta">
                    <div class="agent-meta-item">
                        <span class="agent-meta-label">Koszt/1k tokenów:</span>
                        <span class="agent-meta-value">$${model.cost_per_1k}</span>
                    </div>
                    <div class="agent-meta-item">
                        <span class="agent-meta-label">Czas odpowiedzi:</span>
                        <span class="agent-meta-value">${model.avg_response_time}s</span>
                    </div>
                    <div class="agent-meta-item">
                        <span class="agent-meta-label">Wskaźnik sukcesu:</span>
                        <span class="agent-meta-value">${Math.round(model.success_rate * 100)}%</span>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

function initializeChart() {
    const canvas = document.getElementById('performanceChart');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    
    // Simple chart implementation
    const data = appData.metrics.daily_stats;
    const width = canvas.width;
    const height = canvas.height;
    const padding = 40;
    
    // Clear canvas
    ctx.clearRect(0, 0, width, height);
    
    // Set styles
    ctx.strokeStyle = '#21808D';
    ctx.fillStyle = '#21808D';
    ctx.lineWidth = 2;
    
    // Calculate dimensions
    const chartWidth = width - (padding * 2);
    const chartHeight = height - (padding * 2);
    const maxSessions = Math.max(...data.map(d => d.sessions));
    
    // Draw axes
    ctx.beginPath();
    ctx.strokeStyle = '#5E5240';
    ctx.lineWidth = 1;
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, height - padding);
    ctx.lineTo(width - padding, height - padding);
    ctx.stroke();
    
    // Draw data points and lines
    ctx.beginPath();
    ctx.strokeStyle = '#21808D';
    ctx.lineWidth = 2;
    
    data.forEach((point, index) => {
        const x = padding + (index / (data.length - 1)) * chartWidth;
        const y = height - padding - (point.sessions / maxSessions) * chartHeight;
        
        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });
    
    ctx.stroke();
    
    // Draw data points
    ctx.fillStyle = '#21808D';
    data.forEach((point, index) => {
        const x = padding + (index / (data.length - 1)) * chartWidth;
        const y = height - padding - (point.sessions / maxSessions) * chartHeight;
        
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, 2 * Math.PI);
        ctx.fill();
    });
}

// Modal functions
function openAgentModal() {
    if (agentModal) {
        agentModal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeAgentModal() {
    if (agentModal) {
        agentModal.classList.remove('active');
        document.body.style.overflow = '';
        // Reset form
        const form = document.getElementById('agentForm');
        if (form) {
            form.reset();
        }
    }
}

function saveNewAgent() {
    const agentName = document.getElementById('agentName');
    const agentModel = document.getElementById('agentModel');
    
    if (!agentName || !agentModel || !agentName.value.trim()) {
        showNotification('Proszę wypełnić wszystkie wymagane pola', 'error');
        return;
    }
    
    const newAgent = {
        id: appData.agents.length + 1,
        name: agentName.value.trim(),
        model: agentModel.value,
        status: 'idle',
        sessions: 0,
        success_rate: 0,
        last_task: 'Nowy agent',
        created: new Date().toISOString()
    };
    
    appData.agents.push(newAgent);
    appData.metrics.active_agents = appData.agents.filter(a => a.status === 'active').length;
    
    renderAgents();
    updateMetrics();
    closeAgentModal();
    
    // Show success message
    showNotification('Agent został dodany pomyślnie!', 'success');
}

// Utility functions
function formatTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleTimeString('pl-PL', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pl-PL', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">×</button>
    `;
    
    // Add styles if not exists
    if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: var(--color-surface);
                border: 1px solid var(--color-border);
                border-radius: var(--radius-base);
                padding: var(--space-16);
                box-shadow: var(--shadow-lg);
                z-index: 3000;
                display: flex;
                align-items: center;
                gap: var(--space-12);
                max-width: 400px;
                animation: slideIn 0.3s ease-out;
            }
            .notification--success {
                border-left: 4px solid var(--color-success);
            }
            .notification--error {
                border-left: 4px solid var(--color-error);
            }
            .notification--info {
                border-left: 4px solid var(--color-primary);
            }
            .notification button {
                background: none;
                border: none;
                cursor: pointer;
                color: var(--color-text-secondary);
                font-size: 18px;
                line-height: 1;
            }
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.style.animation = 'slideOut 0.3s ease-in forwards';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

// Placeholder functions for agent actions
function viewAgentLogs(agentId) {
    showNotification(`Wyświetlanie logów dla agenta ID: ${agentId}`, 'info');
}

function configureAgent(agentId) {
    showNotification(`Konfiguracja agenta ID: ${agentId}`, 'info');
}

function viewSessionDetails(sessionId) {
    showNotification(`Szczegóły sesji ID: ${sessionId}`, 'info');
}

// Simulate real-time updates
setInterval(() => {
    // Update random metrics slightly
    const resourceFills = document.querySelectorAll('.resource-fill');
    resourceFills.forEach(fill => {
        const currentWidth = parseInt(fill.style.width) || 0;
        const newWidth = Math.max(10, Math.min(90, currentWidth + (Math.random() - 0.5) * 5));
        fill.style.width = newWidth + '%';
    });
}, 5000);

// Handle window resize
window.addEventListener('resize', () => {
    if (window.innerWidth > 768 && sidebar) {
        sidebar.classList.remove('mobile-open');
    }
});