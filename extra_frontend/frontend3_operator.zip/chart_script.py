import plotly.graph_objects as go
import plotly.io as pio

# Data for the architecture diagram with better abbreviations
layers = [
    {
        "name": "Frontend Layer",
        "components": ["Dashboard", "Agent Mgr", "Session View", "RT Monitor"],
        "color": "#3B82F6",
        "y_position": 3
    },
    {
        "name": "Backend Layer", 
        "components": ["FastAPI Svr", "WebSocket Hdlr", "Agent Ctrl", "Data Proc"],
        "color": "#10B981",
        "y_position": 2
    },
    {
        "name": "Data Layer",
        "components": ["SQLite DB", "Config YAML", "Trajectory", "Model Cache"],
        "color": "#F59E0B",
        "y_position": 1
    },
    {
        "name": "External Services",
        "components": ["OpenAI API", "Anthropic API", "Google AI", "Playwright", "iMean Builder"],
        "color": "#6B7280",
        "y_position": 0
    }
]

# Create the figure
fig = go.Figure()

# Add layer rectangles and component boxes
for layer in layers:
    y_pos = layer["y_position"]
    
    # Add layer background rectangle
    fig.add_shape(
        type="rect",
        x0=-0.5, y0=y_pos-0.4,
        x1=len(layer["components"])-0.5, y1=y_pos+0.4,
        fillcolor=layer["color"],
        opacity=0.2,
        line=dict(color=layer["color"], width=2)
    )
    
    # Add component boxes
    for i, component in enumerate(layer["components"]):
        fig.add_shape(
            type="rect",
            x0=i-0.4, y0=y_pos-0.3,
            x1=i+0.4, y1=y_pos+0.3,
            fillcolor=layer["color"],
            opacity=0.8,
            line=dict(color="white", width=1)
        )
        
        # Add component text
        fig.add_annotation(
            x=i, y=y_pos,
            text=component,
            showarrow=False,
            font=dict(color="white", size=10),
            align="center"
        )
    
    # Add layer title with consistent color
    fig.add_annotation(
        x=-0.7, y=y_pos,
        text=layer["name"],
        showarrow=False,
        font=dict(color="#333", size=12, family="Arial Black"),
        align="right",
        textangle=90
    )

# Add arrow shapes for data flow connections
# Frontend to Backend arrow
fig.add_shape(
    type="line",
    x0=1.5, y0=2.7,
    x1=1.5, y1=2.4,
    line=dict(color="#333", width=3),
)
fig.add_annotation(
    x=1.5, y=2.4,
    ax=1.5, ay=2.7,
    arrowhead=2, arrowsize=1.5, arrowwidth=3, arrowcolor="#333",
    text="",
    showarrow=True
)
fig.add_annotation(
    x=2.2, y=2.55,
    text="WebSocket<br>REST API",
    showarrow=False,
    font=dict(size=10, color="#333"),
    align="left"
)

# Backend to Data arrow
fig.add_shape(
    type="line",
    x0=1.5, y0=1.7,
    x1=1.5, y1=1.4,
    line=dict(color="#333", width=3),
)
fig.add_annotation(
    x=1.5, y=1.4,
    ax=1.5, ay=1.7,
    arrowhead=2, arrowsize=1.5, arrowwidth=3, arrowcolor="#333",
    text="",
    showarrow=True
)
fig.add_annotation(
    x=2.2, y=1.55,
    text="DB Access<br>File I/O",
    showarrow=False,
    font=dict(size=10, color="#333"),
    align="left"
)

# Backend to External arrow
fig.add_shape(
    type="line",
    x0=2.5, y0=1.7,
    x1=2.5, y1=0.4,
    line=dict(color="#333", width=3),
)
fig.add_annotation(
    x=2.5, y=0.4,
    ax=2.5, ay=1.7,
    arrowhead=2, arrowsize=1.5, arrowwidth=3, arrowcolor="#333",
    text="",
    showarrow=True
)
fig.add_annotation(
    x=3.2, y=1.05,
    text="API Calls<br>Browser Ctrl",
    showarrow=False,
    font=dict(size=10, color="#333"),
    align="left"
)

# Update layout
fig.update_layout(
    title="System Architecture Diagram",
    showlegend=False,
    xaxis=dict(visible=False, range=[-1, 6]),
    yaxis=dict(visible=False, range=[-0.8, 3.8]),
    plot_bgcolor="white"
)

# Save the chart
fig.write_image("architecture_diagram.png", width=800, height=600, scale=2)
fig.show()