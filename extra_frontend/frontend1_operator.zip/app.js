// Application data
const appData = {
  "agents": [
    {
      "id": "shopping-bot",
      "name": "Shopping Assistant",
      "status": "active",
      "model": "gpt-4o",
      "config": {
        "browser": "chrome",
        "headless": false,
        "timeout": 30000,
        "actions": ["click", "type", "scroll", "screenshot"]
      },
      "metrics": {
        "success_rate": 0.85,
        "avg_time": 12.4,
        "total_runs": 23
      }
    },
    {
      "id": "research-agent", 
      "name": "Research Helper",
      "status": "idle",
      "model": "claude-3.5-sonnet",
      "config": {
        "browser": "firefox",
        "headless": true,
        "timeout": 60000,
        "actions": ["navigate", "extract", "analyze"]
      },
      "metrics": {
        "success_rate": 0.92,
        "avg_time": 8.7,
        "total_runs": 156
      }
    }
  ],
  "models": [
    {
      "provider": "openai",
      "model": "gpt-4o",
      "quota_used": 0.45,
      "cost_per_1k": 0.005,
      "status": "online"
    },
    {
      "provider": "anthropic",
      "model": "claude-3.5-sonnet",
      "quota_used": 0.23,
      "cost_per_1k": 0.003,
      "status": "online"
    },
    {
      "provider": "google",
      "model": "gemini-pro", 
      "quota_used": 0.12,
      "cost_per_1k": 0.002,
      "status": "online"
    },
    {
      "provider": "deepseek",
      "model": "deepseek-r1",
      "quota_used": 0.08,
      "cost_per_1k": 0.0,
      "status": "online"
    }
  ],
  "sessions": [
    {
      "id": "session-001",
      "agent": "shopping-bot",
      "start_time": "2025-06-28T10:30:00Z",
      "status": "completed",
      "steps": 15,
      "success": true,
      "trajectory": [
        {"action": "navigate", "url": "https://amazon.com", "timestamp": "10:30:01"},
        {"action": "type", "selector": "#twotabsearchtextbox", "value": "laptop", "timestamp": "10:30:05"},
        {"action": "click", "selector": ".nav-search-submit", "timestamp": "10:30:07"}
      ]
    }
  ],
  "system_stats": {
    "cpu_usage": 0.34,
    "memory_usage": 0.67,
    "active_agents": 1,
    "total_sessions": 179,
    "uptime": "2d 14h 32m"
  }
};

// Application state
let currentAgent = 'shopping-bot';
let currentTab = 'config';
let terminalCollapsed = false;
let agentRunning = false;

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    setupKeyboardShortcuts();
    loadAgentConfig();
    updateLineNumbers();
    startRealTimeUpdates();
});

function initializeApp() {
    // Update status bar with current data
    updateStatusBar();
    
    // Set initial editor content
    const configEditor = document.getElementById('config-editor');
    configEditor.value = generateAgentConfigYAML(currentAgent);
    
    // Initialize terminal with startup messages
    addTerminalLine('[INFO] Agent system initialized', 'info');
    addTerminalLine('[DEBUG] WebSocket connection established', 'debug');
    addTerminalLine('[SUCCESS] shopping-bot ready for execution', 'success');
    addTerminalLine('[INFO] Memory usage: 67% | CPU: 34%', 'info');
}

function setupEventListeners() {
    // Tab switching
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', function() {
            switchTab(this.dataset.tab);
        });
    });
    
    // Sidebar section toggling
    document.querySelectorAll('.section-header').forEach(header => {
        header.addEventListener('click', function() {
            toggleSection(this.dataset.section);
        });
    });
    
    // Agent selection
    document.querySelectorAll('.agent-item').forEach(item => {
        item.addEventListener('click', function() {
            selectAgent(this.dataset.agent);
        });
    });
    
    // Model selection
    document.querySelectorAll('.model-item').forEach(item => {
        item.addEventListener('click', function() {
            selectModel(this.dataset.model);
        });
    });
    
    // Editor actions
    document.getElementById('save-config').addEventListener('click', saveConfig);
    document.getElementById('validate-config').addEventListener('click', validateConfig);
    document.getElementById('start-agent').addEventListener('click', startAgent);
    document.getElementById('stop-agent').addEventListener('click', stopAgent);
    
    // Terminal controls
    document.getElementById('clear-terminal').addEventListener('click', clearTerminal);
    document.getElementById('toggle-terminal').addEventListener('click', toggleTerminal);
    
    // Terminal input
    document.getElementById('terminal-input').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            executeTerminalCommand(this.value);
            this.value = '';
        }
    });
    
    // Code editor input
    document.getElementById('config-editor').addEventListener('input', function() {
        updateLineNumbers();
        validateConfigRealTime();
    });
    
    // Terminal tab switching
    document.querySelectorAll('.terminal-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            switchTerminalTab(this);
        });
    });
}

function setupKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // F5 - Start/Stop Agent
        if (e.key === 'F5') {
            e.preventDefault();
            if (agentRunning) {
                stopAgent();
            } else {
                startAgent();
            }
        }
        
        // Ctrl+` - Toggle Terminal
        if (e.ctrlKey && e.key === '`') {
            e.preventDefault();
            toggleTerminal();
        }
        
        // Ctrl+S - Save Config
        if (e.ctrlKey && e.key === 's') {
            e.preventDefault();
            saveConfig();
        }
        
        // Ctrl+Shift+P - Command Palette (placeholder)
        if (e.ctrlKey && e.shiftKey && e.key === 'P') {
            e.preventDefault();
            addTerminalLine('[INFO] Command Palette - feature coming soon', 'info');
        }
        
        // Ctrl+E - Quick File Switcher (placeholder)
        if (e.ctrlKey && e.key === 'e') {
            e.preventDefault();
            addTerminalLine('[INFO] Quick File Switcher - feature coming soon', 'info');
        }
    });
}

function switchTab(tabName) {
    // Update tab appearance
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    
    // Update panel visibility
    document.querySelectorAll('.editor-panel').forEach(panel => {
        panel.classList.remove('active');
    });
    document.getElementById(`${tabName}-panel`).classList.add('active');
    
    currentTab = tabName;
    
    // Load appropriate content
    if (tabName === 'config') {
        loadAgentConfig();
    } else if (tabName === 'models') {
        loadModelConfig();
    }
}

function toggleSection(sectionName) {
    const section = document.querySelector(`[data-section="${sectionName}"]`).closest('.section');
    section.classList.toggle('collapsed');
}

function selectAgent(agentId) {
    // Update selection visual state
    document.querySelectorAll('.agent-item').forEach(item => {
        item.classList.remove('selected');
    });
    document.querySelector(`[data-agent="${agentId}"]`).classList.add('selected');
    
    currentAgent = agentId;
    
    // Load agent configuration
    loadAgentConfig();
    
    // Update terminal
    addTerminalLine(`[INFO] Switching to agent: ${agentId}`, 'info');
    
    // Update status bar
    updateStatusBar();
}

function selectModel(modelId) {
    // Update current agent's model
    const agent = appData.agents.find(a => a.id === currentAgent);
    if (agent) {
        agent.model = modelId;
        addTerminalLine(`[INFO] Model switched to: ${modelId}`, 'info');
        loadAgentConfig();
        updateStatusBar();
    }
}

function generateAgentConfigYAML(agentId) {
    const agent = appData.agents.find(a => a.id === agentId);
    if (!agent) return '';
    
    return `# Agent Configuration: ${agent.name}
name: "${agent.name}"
id: "${agent.id}"
status: "${agent.status}"

# Model Configuration
model:
  provider: "${agent.model.includes('gpt') ? 'openai' : agent.model.includes('claude') ? 'anthropic' : agent.model.includes('gemini') ? 'google' : 'deepseek'}"
  name: "${agent.model}"
  temperature: 0.7
  max_tokens: 4096

# Browser Configuration
browser:
  type: "${agent.config.browser}"
  headless: ${agent.config.headless}
  timeout: ${agent.config.timeout}
  viewport:
    width: 1920
    height: 1080

# Available Actions
actions:
${agent.config.actions.map(action => `  - "${action}"`).join('\n')}

# Selectors Configuration
selectors:
  wait_timeout: 5000
  retry_attempts: 3
  
# Performance Metrics
metrics:
  success_rate: ${agent.metrics.success_rate}
  average_time: ${agent.metrics.avg_time}s
  total_runs: ${agent.metrics.total_runs}

# Logging
logging:
  level: "INFO"
  output: "console"
  save_screenshots: true`;
}

function loadAgentConfig() {
    const configEditor = document.getElementById('config-editor');
    configEditor.value = generateAgentConfigYAML(currentAgent);
    updateLineNumbers();
}

function loadModelConfig() {
    const modelConfig = document.querySelector('.model-config');
    modelConfig.innerHTML = '';
    
    appData.models.forEach(model => {
        const providerDiv = document.createElement('div');
        providerDiv.className = 'model-provider';
        
        const quotaPercentage = Math.round(model.quota_used * 100);
        const costDisplay = model.cost_per_1k === 0 ? 'FREE' : `$${model.cost_per_1k}`;
        
        providerDiv.innerHTML = `
            <div class="provider-header">
                <span class="provider-name">${model.provider.toUpperCase()} ${model.model}</span>
                <span class="provider-status ${model.status}">●</span>
            </div>
            <div class="provider-details">
                <div class="detail-row">
                    <span>Quota Used:</span>
                    <span class="quota-bar">
                        <div class="quota-fill" style="width: ${quotaPercentage}%"></div>
                        <span class="quota-text">${quotaPercentage}%</span>
                    </span>
                </div>
                <div class="detail-row">
                    <span>Cost per 1K:</span>
                    <span>${costDisplay}</span>
                </div>
            </div>
        `;
        
        modelConfig.appendChild(providerDiv);
    });
}

function updateLineNumbers() {
    const codeEditor = document.getElementById('config-editor');
    const lineNumbers = document.querySelector('.line-numbers');
    
    const lines = codeEditor.value.split('\n').length;
    const numbers = Array.from({length: lines}, (_, i) => i + 1);
    
    lineNumbers.innerHTML = numbers.join('\n');
}

function validateConfig() {
    const configEditor = document.getElementById('config-editor');
    const config = configEditor.value;
    
    try {
        // Basic YAML validation simulation
        if (config.includes('name:') && config.includes('model:') && config.includes('browser:')) {
            addTerminalLine('[SUCCESS] Configuration validation passed', 'success');
            return true;
        } else {
            throw new Error('Missing required fields');
        }
    } catch (error) {
        addTerminalLine(`[ERROR] Configuration validation failed: ${error.message}`, 'error');
        return false;
    }
}

function validateConfigRealTime() {
    // Real-time validation feedback
    const configEditor = document.getElementById('config-editor');
    const config = configEditor.value;
    
    // Simple validation indicators
    if (config.includes('invalid') || config.includes('error')) {
        configEditor.style.borderLeft = '3px solid var(--color-error)';
    } else {
        configEditor.style.borderLeft = '3px solid var(--color-accent-green)';
    }
}

function saveConfig() {
    if (validateConfig()) {
        addTerminalLine(`[INFO] Configuration saved for ${currentAgent}`, 'info');
        // Simulate save delay
        setTimeout(() => {
            addTerminalLine('[SUCCESS] Configuration saved successfully', 'success');
        }, 500);
    }
}

function startAgent() {
    if (agentRunning) return;
    
    agentRunning = true;
    document.getElementById('start-agent').disabled = true;
    document.getElementById('stop-agent').disabled = false;
    
    // Update agent status
    const agent = appData.agents.find(a => a.id === currentAgent);
    if (agent) {
        agent.status = 'running';
    }
    
    addTerminalLine(`[INFO] Starting agent: ${currentAgent}`, 'info');
    addTerminalLine('[DEBUG] Initializing browser session', 'debug');
    
    // Simulate agent execution
    simulateAgentExecution();
    
    // Switch to session tab
    switchTab('session');
    
    updateStatusBar();
}

function stopAgent() {
    if (!agentRunning) return;
    
    agentRunning = false;
    document.getElementById('start-agent').disabled = false;
    document.getElementById('stop-agent').disabled = true;
    
    // Update agent status
    const agent = appData.agents.find(a => a.id === currentAgent);
    if (agent) {
        agent.status = 'idle';
    }
    
    addTerminalLine(`[INFO] Stopping agent: ${currentAgent}`, 'info');
    addTerminalLine('[SUCCESS] Agent stopped successfully', 'success');
    
    updateStatusBar();
}

function simulateAgentExecution() {
    const sessionOutput = document.getElementById('session-output');
    
    // Clear previous session
    sessionOutput.innerHTML = '';
    
    const steps = [
        { text: '[2025-06-28 10:30:00] Session initialized', delay: 500 },
        { text: '[2025-06-28 10:30:01] Loading browser configuration', delay: 1000 },
        { text: '[2025-06-28 10:30:02] Starting Chrome browser', delay: 1500 },
        { text: '[2025-06-28 10:30:03] Navigating to target URL', delay: 2000 },
        { text: '[2025-06-28 10:30:05] Page loaded successfully', delay: 2500, class: 'success' },
        { text: '[2025-06-28 10:30:06] Locating search input field', delay: 3000 },
        { text: '[2025-06-28 10:30:07] Typing search query', delay: 3500, class: 'success' },
        { text: '[2025-06-28 10:30:08] Clicking search button', delay: 4000 },
        { text: '[2025-06-28 10:30:10] Processing search results', delay: 4500 },
        { text: '[2025-06-28 10:30:12] Session completed successfully', delay: 5000, class: 'success' }
    ];
    
    steps.forEach((step, index) => {
        setTimeout(() => {
            const line = document.createElement('div');
            line.className = `session-line ${step.class || ''}`;
            line.textContent = step.text;
            sessionOutput.appendChild(line);
            sessionOutput.scrollTop = sessionOutput.scrollHeight;
            
            // Add to terminal as well
            addTerminalLine(step.text, step.class || 'info');
            
            // Stop agent after completion
            if (index === steps.length - 1) {
                setTimeout(() => {
                    stopAgent();
                }, 1000);
            }
        }, step.delay);
    });
}

function addTerminalLine(text, type = 'info') {
    const terminalOutput = document.getElementById('terminal-output');
    const line = document.createElement('div');
    line.className = `terminal-line ${type}`;
    line.textContent = text;
    terminalOutput.appendChild(line);
    terminalOutput.scrollTop = terminalOutput.scrollHeight;
}

function clearTerminal() {
    document.getElementById('terminal-output').innerHTML = '';
    addTerminalLine('[INFO] Terminal cleared', 'info');
}

function toggleTerminal() {
    const terminalPanel = document.querySelector('.terminal-panel');
    const toggleBtn = document.getElementById('toggle-terminal');
    
    if (terminalCollapsed) {
        terminalPanel.style.height = 'var(--terminal-height)';
        toggleBtn.textContent = '^';
        terminalCollapsed = false;
    } else {
        terminalPanel.style.height = '32px';
        toggleBtn.textContent = 'v';
        terminalCollapsed = true;
    }
}

function executeTerminalCommand(command) {
    addTerminalLine(`$ ${command}`, 'info');
    
    // Simple command processing
    const cmd = command.toLowerCase().trim();
    
    if (cmd === 'help') {
        addTerminalLine('Available commands: help, status, agents, models, clear, start, stop', 'info');
    } else if (cmd === 'status') {
        addTerminalLine(`Active agents: ${appData.system_stats.active_agents}`, 'info');
        addTerminalLine(`CPU: ${Math.round(appData.system_stats.cpu_usage * 100)}%`, 'info');
        addTerminalLine(`Memory: ${Math.round(appData.system_stats.memory_usage * 100)}%`, 'info');
    } else if (cmd === 'agents') {
        appData.agents.forEach(agent => {
            addTerminalLine(`${agent.id}: ${agent.status} (${agent.model})`, 'info');
        });
    } else if (cmd === 'models') {
        appData.models.forEach(model => {
            addTerminalLine(`${model.model}: ${model.status} (${Math.round(model.quota_used * 100)}% used)`, 'info');
        });
    } else if (cmd === 'clear') {
        clearTerminal();
    } else if (cmd === 'start') {
        startAgent();
    } else if (cmd === 'stop') {
        stopAgent();
    } else {
        addTerminalLine(`Command not found: ${command}`, 'error');
    }
}

function switchTerminalTab(tab) {
    document.querySelectorAll('.terminal-tab').forEach(t => {
        t.classList.remove('active');
    });
    tab.classList.add('active');
    
    const tabName = tab.textContent;
    if (tabName === 'Performance') {
        showPerformanceMetrics();
    } else if (tabName === 'Errors') {
        showErrorLogs();
    }
}

function showPerformanceMetrics() {
    const terminalOutput = document.getElementById('terminal-output');
    terminalOutput.innerHTML = '';
    
    addTerminalLine('=== PERFORMANCE METRICS ===', 'info');
    addTerminalLine(`CPU Usage: ${Math.round(appData.system_stats.cpu_usage * 100)}%`, 'info');
    addTerminalLine(`Memory Usage: ${Math.round(appData.system_stats.memory_usage * 100)}%`, 'info');
    addTerminalLine(`Uptime: ${appData.system_stats.uptime}`, 'info');
    addTerminalLine(`Total Sessions: ${appData.system_stats.total_sessions}`, 'info');
    addTerminalLine('', 'info');
    
    appData.agents.forEach(agent => {
        addTerminalLine(`Agent: ${agent.id}`, 'info');
        addTerminalLine(`  Success Rate: ${Math.round(agent.metrics.success_rate * 100)}%`, 'success');
        addTerminalLine(`  Avg Time: ${agent.metrics.avg_time}s`, 'info');
        addTerminalLine(`  Total Runs: ${agent.metrics.total_runs}`, 'info');
    });
}

function showErrorLogs() {
    const terminalOutput = document.getElementById('terminal-output');
    terminalOutput.innerHTML = '';
    
    addTerminalLine('=== ERROR LOGS ===', 'info');
    addTerminalLine('[2025-06-28 09:15:23] [WARNING] High memory usage detected', 'error');
    addTerminalLine('[2025-06-28 08:45:12] [ERROR] Timeout in research-agent session', 'error');
    addTerminalLine('[2025-06-28 07:30:45] [INFO] No critical errors in last 24h', 'success');
}

function updateStatusBar() {
    const agent = appData.agents.find(a => a.id === currentAgent);
    const currentModel = agent ? agent.model : 'none';
    const activeAgents = appData.agents.filter(a => a.status === 'active' || a.status === 'running').length;
    
    // Update status items
    document.querySelector('.status-left').innerHTML = `
        <span class="status-item">🤖 Active Agents: <strong>${activeAgents}</strong></span>
        <span class="status-item">📊 Sessions: <strong>${appData.system_stats.total_sessions}</strong></span>
        <span class="status-item">⏱️ Uptime: <strong>${appData.system_stats.uptime}</strong></span>
    `;
    
    document.querySelector('.status-right').innerHTML = `
        <span class="status-item">💾 Memory: <strong>${Math.round(appData.system_stats.memory_usage * 100)}%</strong></span>
        <span class="status-item">⚡ CPU: <strong>${Math.round(appData.system_stats.cpu_usage * 100)}%</strong></span>
        <span class="status-item">🧠 Model: <strong>${currentModel}</strong></span>
        <span class="status-item online">● Online</span>
    `;
}

function startRealTimeUpdates() {
    // Simulate real-time system updates
    setInterval(() => {
        // Update system stats with small random variations
        appData.system_stats.cpu_usage = Math.max(0.1, Math.min(0.9, appData.system_stats.cpu_usage + (Math.random() - 0.5) * 0.1));
        appData.system_stats.memory_usage = Math.max(0.3, Math.min(0.9, appData.system_stats.memory_usage + (Math.random() - 0.5) * 0.05));
        
        updateStatusBar();
    }, 5000);
    
    // Simulate occasional system messages
    setInterval(() => {
        const messages = [
            '[DEBUG] Heartbeat check passed',
            '[INFO] Memory cleanup completed',
            '[DEBUG] WebSocket connection stable',
            '[INFO] Configuration auto-saved'
        ];
        
        const randomMessage = messages[Math.floor(Math.random() * messages.length)];
        if (Math.random() < 0.3) { // 30% chance every interval
            addTerminalLine(randomMessage, 'debug');
        }
    }, 10000);
}