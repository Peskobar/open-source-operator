# Kompletna Instrukcja Instalacji - Agent Code Studio

## Przegląd Architektury

Agent Code Studio to nowoczesny frontend w stylu IDE dla open-source-operator, który zastępuje prosty interfejs Gradio zaawansowanym code-first management system. Składa się z:

1. **Frontend**: IDE-style interface z syntax highlighting, real-time monitoring
2. **Backend**: FastAPI server z WebSocket communication
3. **Database**: SQLite dla persistence agentów i sesji
4. **Integration**: Pełna kompatybilność z istniejącym open-source-operator

## Instalacja Krok po Kroku

### 1. Przygotowanie Środowiska

```bash
# Klonowanie repozytorium
git clone https://github.com/Peskobar/open-source-operator.git
cd open-source-operator

# Tworzenie virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# lub
venv\Scripts\activate     # Windows

# Backup istniejącego Gradio interface
mv inference/app.py inference/app_gradio_backup.py
```

### 2. Instalacja Dependencies

```bash
# Podstawowe dependencies
pip install fastapi==0.104.1
pip install uvicorn[standard]==0.24.0
pip install websockets==12.0
pip install pyyaml==6.0.1
pip install psutil==5.9.6
pip install aiofiles==23.2.1
pip install python-multipart==0.0.6

# Zachowanie istniejących dependencies z requirements.txt
pip install -r requirements.txt
```

### 3. Konfiguracja Backend

Stwórz nowy plik `inference/app_fastapi.py` z kodem z poprzedniego pliku markdown.

```bash
# Skopiuj kod FastAPI backend do
# inference/app_fastapi.py
```

### 4. Instalacja Frontend

```bash
# Tworzenie struktury folderów
mkdir -p frontend/static/css
mkdir -p frontend/static/js
mkdir -p frontend/static/assets

# Skopiowanie plików frontend (z wygenerowanej aplikacji)
# index.html -> frontend/index.html
# style.css -> frontend/static/css/style.css  
# app.js -> frontend/static/js/app.js
```

### 5. Konfiguracja Environment Variables

```bash
# Plik .env w root directory
touch .env

# Dodaj API keys
echo "OPENAI_API_KEY=your_openai_key" >> .env
echo "ANTHROPIC_API_KEY=your_anthropic_key" >> .env
echo "GOOGLE_API_KEY=your_google_key" >> .env
echo "DEEPSEEK_API_KEY=your_deepseek_key" >> .env
echo "BROWSERBASE_API_KEY=your_browserbase_key" >> .env
echo "IMEAN_USERNAME=your_imean_username" >> .env
echo "IMEAN_PASSWORD=your_imean_password" >> .env
```

### 6. Aktualizacja Konfiguracji

Zaktualizuj `configs/config.yaml`:

```yaml
# Agent Code Studio Configuration
server:
  host: "0.0.0.0"
  port: 7860
  debug: true

models:
  openai:
    api_key: "${OPENAI_API_KEY}"
    model: "gpt-4o"
    max_tokens: 4096
  anthropic:
    api_key: "${ANTHROPIC_API_KEY}" 
    model: "claude-3.5-sonnet"
    max_tokens: 4096
  google:
    api_key: "${GOOGLE_API_KEY}"
    model: "gemini-pro"
    max_tokens: 4096
  deepseek:
    api_key: "${DEEPSEEK_API_KEY}"
    model: "deepseek-r1"
    max_tokens: 4096

browser:
  default: "chrome"
  timeout: 30000
  headless: false
  browserbase:
    api_key: "${BROWSERBASE_API_KEY}"
    enabled: true

data:
  challenge_id: "default_challenge"
  mode: "dom_tree"  # or "vision"
  storage_path: "./data/sft/"

imean_builder:
  username: "${IMEAN_USERNAME}"
  password: "${IMEAN_PASSWORD}"
  
webcanvas:
  evaluation_endpoint: "https://api.webcanvas.com/eval"
  
agent_code_studio:
  theme: "dark"
  auto_save: true
  syntax_highlighting: true
  real_time_updates: true
```

## Uruchomienie Systemu

### Standardowe Uruchomienie

```bash
# Uruchomienie z nowym FastAPI backend
python inference/app_fastapi.py

# Alternatywnie z uvicorn
uvicorn inference.app_fastapi:app --host 0.0.0.0 --port 7860 --reload
```

### Docker Setup (Opcjonalnie)

```dockerfile
# Dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

EXPOSE 7860

CMD ["python", "inference/app_fastapi.py"]
```

```yaml
# docker-compose.yml
version: '3.8'
services:
  agent-code-studio:
    build: .
    ports:
      - "7860:7860"
    environment:
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY}
    volumes:
      - ./data:/app/data
      - ./configs:/app/configs
```

## Dostęp do Aplikacji

Po uruchomieniu aplikacja będzie dostępna pod adresem:

- **Frontend**: http://localhost:7860
- **API Documentation**: http://localhost:7860/docs
- **WebSocket**: ws://localhost:7860/ws

## Struktura Projektu Po Instalacji

```
open-source-operator/
├── configs/
│   └── config.yaml           # Zaktualizowana konfiguracja
├── frontend/                 # Nowy frontend
│   ├── index.html
│   └── static/
│       ├── css/style.css
│       ├── js/app.js
│       └── assets/
├── inference/
│   ├── app_fastapi.py        # Nowy FastAPI backend
│   └── app_gradio_backup.py  # Backup Gradio
├── data/
│   └── sft/                  # Trajectory data
├── agents.db                 # SQLite database
├── .env                      # Environment variables
└── requirements.txt          # Dependencies
```

## Testowanie Instalacji

### 1. Health Check

```bash
curl http://localhost:7860/api/health
# Powinien zwrócić: {"status": "healthy", "timestamp": "..."}
```

### 2. Test WebSocket

```javascript
// W konsoli przeglądarki
const ws = new WebSocket('ws://localhost:7860/ws');
ws.onopen = () => console.log('Connected');
ws.onmessage = (event) => console.log('Message:', event.data);
ws.send(JSON.stringify({type: 'ping'}));
```

### 3. Test API Endpoints

```bash
# Lista agentów
curl http://localhost:7860/api/agents

# System metrics
curl http://localhost:7860/api/system/metrics

# Modele AI
curl http://localhost:7860/api/models
```

## Funkcjonalności Po Instalacji

### Code-First Agent Management
- Edycja konfiguracji agentów w YAML/JSON z syntax highlighting
- IntelliSense dla supported actions i selectors
- Real-time validation konfiguracji

### IDE-Style Interface
- Sidebar explorer z agent workspace
- Main editor area z multiple tabs
- Terminal panel z real-time logs
- Status bar z system metrics

### Real-time Monitoring
- WebSocket komunikacja
- Live session view
- Performance metrics
- Error tracking

### AI Model Integration
- Obsługa multiple providers (OpenAI, Anthropic, Google, DeepSeek)
- Automatic fallback między modelami
- Quota monitoring i cost tracking
- A/B testing interface

### Trajectory Analysis
- Git-style diff viewer dla trajektorii
- WebCanvas integration
- iMean Builder import
- Automated evaluation

## Troubleshooting

### Problem: Frontend nie ładuje się
```bash
# Sprawdź czy pliki frontend są w właściwym miejscu
ls -la frontend/
ls -la frontend/static/

# Sprawdź logi backend
tail -f logs/app.log
```

### Problem: WebSocket connection failed
```bash
# Sprawdź czy port 7860 jest dostępny
netstat -an | grep 7860

# Sprawdź firewall settings
sudo ufw status
```

### Problem: Agent nie startuje
```bash
# Sprawdź API keys w .env
grep API_KEY .env

# Sprawdź logs w terminal panel
# Lub sprawdź bezpośrednio w aplikacji
```

### Problem: Baza danych błędy
```bash
# Reset bazy danych
rm agents.db
python -c "from inference.app_fastapi import init_database; init_database()"
```

## Migracja z Gradio

Jeśli używałeś poprzednio Gradio interface:

1. **Backup danych**: Skopiuj istniejące trajectory files z `data/sft/`
2. **Konfiguracja**: Zachowaj ustawienia z `configs/config.yaml`  
3. **Environment**: Skopiuj environment variables
4. **API Keys**: Zachowaj istniejące klucze API

## Performance Tuning

### Dla większych instalacji:

```python
# W app_fastapi.py, zwiększ connection pools
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    max_age=3600,
)

# Włącz caching
from functools import lru_cache

@lru_cache(maxsize=100)
def cached_system_metrics():
    return get_system_metrics()
```

### Monitoring Production:

```bash
# Dodaj monitoring z Prometheus
pip install prometheus-client

# W app_fastapi.py
from prometheus_client import Counter, Histogram
REQUEST_COUNT = Counter('requests_total', 'Total requests')
REQUEST_LATENCY = Histogram('request_duration_seconds', 'Request latency')
```

## Wsparcie i Rozwój

- **Issues**: Zgłaszaj problemy w repozytorium GitHub
- **Features**: Sugeruj nowe funkcjonalności  
- **Documentation**: Dokumentacja dostępna w `/docs`
- **Community**: Dołącz do dyskusji o open-source agents

Agent Code Studio to przyszłość zarządzania agentami AI - professional, skalowalne i developer-friendly rozwiązanie dla nowoczesnych workflow automation.