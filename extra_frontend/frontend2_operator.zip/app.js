// Application State
const AppState = {
    currentSection: 'workspaces',
    selectedWorkspace: null,
    voiceActive: false,
    agentFilter: 'all',
    collaborationActive: false,
    recognition: null,
    synthesis: null
};

// DOM Elements
const Elements = {
    portalOverlay: null,
    mainApp: null,
    enterPortalBtn: null,
    navItems: null,
    contentSections: null,
    voiceBtn: null,
    voiceFeedback: null,
    workspaceCards: null,
    filterBtns: null,
    agentOrbs: null
};

// Initialize Application
document.addEventListener('DOMContentLoaded', function() {
    initializeElements();
    setupEventListeners();
    initializeVoiceInterface();
    startAnimations();
    
    console.log('🚀 Futurystyczny Frontend - Open Source Operator uruchomiony!');
});

// Initialize DOM Elements
function initializeElements() {
    Elements.portalOverlay = document.getElementById('portal-overlay');
    Elements.mainApp = document.getElementById('main-app');
    Elements.enterPortalBtn = document.getElementById('enter-portal');
    Elements.navItems = document.querySelectorAll('.nav-item');
    Elements.contentSections = document.querySelectorAll('.content-section');
    Elements.voiceBtn = document.getElementById('voice-toggle');
    Elements.voiceFeedback = document.getElementById('voice-feedback');
    Elements.workspaceCards = document.querySelectorAll('.workspace-card');
    Elements.filterBtns = document.querySelectorAll('.filter-btn');
    Elements.agentOrbs = document.querySelectorAll('.agent-orb');
}

// Setup Event Listeners
function setupEventListeners() {
    // Portal Entry
    if (Elements.enterPortalBtn) {
        Elements.enterPortalBtn.addEventListener('click', enterApplication);
    }

    // Navigation
    Elements.navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            const section = e.currentTarget.dataset.section;
            navigateToSection(section);
        });
    });

    // Voice Interface
    if (Elements.voiceBtn) {
        Elements.voiceBtn.addEventListener('click', toggleVoiceInterface);
    }

    // Workspace Selection
    Elements.workspaceCards.forEach(card => {
        card.addEventListener('click', (e) => {
            const workspace = e.currentTarget.dataset.workspace;
            selectWorkspace(workspace);
        });
    });

    // Agent Filtering
    Elements.filterBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const filter = e.currentTarget.dataset.filter;
            filterAgents(filter);
        });
    });

    // Agent Interactions
    Elements.agentOrbs.forEach(orb => {
        orb.addEventListener('click', (e) => {
            const agent = e.currentTarget.dataset.agent;
            activateAgent(agent);
        });
    });

    // Keyboard Navigation
    document.addEventListener('keydown', handleKeyboardNavigation);

    // Window Resize
    window.addEventListener('resize', handleResize);
}

// Portal Entry Animation
function enterApplication() {
    Elements.enterPortalBtn.style.transform = 'scale(0.95)';
    
    setTimeout(() => {
        Elements.portalOverlay.style.opacity = '0';
        Elements.portalOverlay.style.transform = 'scale(1.2)';
        
        setTimeout(() => {
            Elements.portalOverlay.classList.add('hidden');
            Elements.mainApp.classList.remove('hidden');
            
            // Start entrance animation
            animateEntrance();
        }, 500);
    }, 300);
}

// Entrance Animation
function animateEntrance() {
    const elements = [
        document.querySelector('.spatial-nav'),
        document.querySelector('.voice-interface'),
        document.querySelector('.spatial-content')
    ];

    elements.forEach((element, index) => {
        if (element) {
            element.style.opacity = '0';
            element.style.transform = 'translateY(30px)';
            
            setTimeout(() => {
                element.style.transition = 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)';
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }, index * 200);
        }
    });
}

// Navigation
function navigateToSection(sectionId) {
    // Update navigation state
    Elements.navItems.forEach(item => {
        item.classList.remove('active');
        if (item.dataset.section === sectionId) {
            item.classList.add('active');
        }
    });

    // Show/hide content sections
    Elements.contentSections.forEach(section => {
        section.classList.remove('active');
        if (section.id === sectionId) {
            section.classList.add('active');
        }
    });

    AppState.currentSection = sectionId;

    // Trigger section-specific animations
    triggerSectionAnimations(sectionId);

    // Voice feedback
    if (AppState.voiceActive) {
        speak(`Przełączono na sekcję ${getSectionName(sectionId)}`);
    }
}

// Get section name in Polish
function getSectionName(sectionId) {
    const names = {
        'workspaces': 'Przestrzenie Robocze',
        'agents': 'Agenci AI',
        'monitor': 'Monitor',
        'collaboration': 'Współpraca'
    };
    return names[sectionId] || sectionId;
}

// Trigger section-specific animations
function triggerSectionAnimations(sectionId) {
    switch(sectionId) {
        case 'workspaces':
            animateWorkspaces();
            break;
        case 'agents':
            animateAgents();
            break;
        case 'monitor':
            animateMonitor();
            break;
        case 'collaboration':
            animateCollaboration();
            break;
    }
}

// Workspace Animations
function animateWorkspaces() {
    const cards = document.querySelectorAll('.workspace-card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px) rotateX(10deg)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.6s cubic-bezier(0.16, 1, 0.3, 1)';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0) rotateX(0deg)';
        }, index * 150);
    });
}

// Agent Animations
function animateAgents() {
    const orbs = document.querySelectorAll('.agent-orb');
    orbs.forEach((orb, index) => {
        orb.style.opacity = '0';
        orb.style.transform = 'translateY(50px) scale(0.8)';
        
        setTimeout(() => {
            orb.style.transition = 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)';
            orb.style.opacity = '1';
            orb.style.transform = 'translateY(0) scale(1)';
        }, index * 100);
    });
}

// Monitor Animations
function animateMonitor() {
    const cards = document.querySelectorAll('.monitor-card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'scale(0.9)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.5s cubic-bezier(0.16, 1, 0.3, 1)';
            card.style.opacity = '1';
            card.style.transform = 'scale(1)';
        }, index * 100);
    });

    // Start real-time updates
    startRealTimeUpdates();
}

// Collaboration Animations
function animateCollaboration() {
    const workspace = document.querySelector('.shared-workspace');
    const integration = document.querySelector('.integration-hub');
    
    [workspace, integration].forEach((element, index) => {
        if (element) {
            element.style.opacity = '0';
            element.style.transform = 'translateX(' + (index === 0 ? '-30px' : '30px') + ')';
            
            setTimeout(() => {
                element.style.transition = 'all 0.6s cubic-bezier(0.16, 1, 0.3, 1)';
                element.style.opacity = '1';
                element.style.transform = 'translateX(0)';
            }, index * 200);
        }
    });
}

// Voice Interface
function initializeVoiceInterface() {
    if ('speechSynthesis' in window) {
        AppState.synthesis = window.speechSynthesis;
    }

    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        AppState.recognition = new SpeechRecognition();
        
        AppState.recognition.continuous = false;
        AppState.recognition.interimResults = false;
        AppState.recognition.lang = 'pl-PL';

        AppState.recognition.onstart = function() {
            console.log('🎤 Rozpoznawanie mowy rozpoczęte');
            showVoiceFeedback();
        };

        AppState.recognition.onresult = function(event) {
            const command = event.results[0][0].transcript.toLowerCase();
            console.log('🗣️ Komenda:', command);
            processVoiceCommand(command);
        };

        AppState.recognition.onerror = function(event) {
            console.error('❌ Błąd rozpoznawania mowy:', event.error);
            hideVoiceFeedback();
        };

        AppState.recognition.onend = function() {
            console.log('🎤 Rozpoznawanie mowy zakończone');
            hideVoiceFeedback();
            AppState.voiceActive = false;
        };
    }
}

// Toggle Voice Interface
function toggleVoiceInterface() {
    if (!AppState.recognition) {
        speak('Rozpoznawanie mowy nie jest dostępne w tej przeglądarce');
        return;
    }

    if (AppState.voiceActive) {
        AppState.recognition.stop();
        AppState.voiceActive = false;
        hideVoiceFeedback();
    } else {
        AppState.recognition.start();
        AppState.voiceActive = true;
    }
}

// Process Voice Commands
function processVoiceCommand(command) {
    hideVoiceFeedback();

    if (command.includes('przestrzeń') || command.includes('workspace')) {
        navigateToSection('workspaces');
    } else if (command.includes('agent') || command.includes('bot')) {
        navigateToSection('agents');
    } else if (command.includes('monitor') || command.includes('statystyki')) {
        navigateToSection('monitor');
    } else if (command.includes('współpraca') || command.includes('zespół')) {
        navigateToSection('collaboration');
    } else if (command.includes('darmowe')) {
        filterAgents('free');
        navigateToSection('agents');
    } else if (command.includes('premium') || command.includes('płatne')) {
        filterAgents('premium');
        navigateToSection('agents');
    } else if (command.includes('centrum dowodzenia')) {
        selectWorkspace('mission-control');
    } else if (command.includes('laboratorium')) {
        selectWorkspace('data-lab');
    } else if (command.includes('studio')) {
        selectWorkspace('creative-studio');
    } else {
        speak('Nie rozpoznano komendy. Spróbuj ponownie.');
    }
}

// Text-to-Speech
function speak(text) {
    if (AppState.synthesis) {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'pl-PL';
        utterance.rate = 0.9;
        utterance.pitch = 1;
        AppState.synthesis.speak(utterance);
    }
}

// Show Voice Feedback
function showVoiceFeedback() {
    if (Elements.voiceFeedback) {
        Elements.voiceFeedback.classList.remove('hidden');
        
        // Animate wave bars
        const waveBars = document.querySelectorAll('.wave-bar');
        waveBars.forEach(bar => {
            bar.style.animationPlayState = 'running';
        });
    }
}

// Hide Voice Feedback
function hideVoiceFeedback() {
    if (Elements.voiceFeedback) {
        Elements.voiceFeedback.classList.add('hidden');
        
        // Stop wave animation
        const waveBars = document.querySelectorAll('.wave-bar');
        waveBars.forEach(bar => {
            bar.style.animationPlayState = 'paused';
        });
    }
}

// Workspace Selection
function selectWorkspace(workspaceId) {
    AppState.selectedWorkspace = workspaceId;
    
    // Visual feedback
    Elements.workspaceCards.forEach(card => {
        card.classList.remove('selected');
        if (card.dataset.workspace === workspaceId) {
            card.classList.add('selected');
            
            // Add selection animation
            card.style.transform = 'translateY(-10px) scale(1.05)';
            card.style.boxShadow = '0 20px 60px rgba(50, 184, 198, 0.6)';
            card.style.borderColor = 'var(--color-primary)';
        }
    });

    // Voice feedback
    speak(`Wybrano przestrzeń roboczą: ${getWorkspaceName(workspaceId)}`);
    
    // Navigate to agents section after selection
    setTimeout(() => {
        navigateToSection('agents');
    }, 1500);
}

// Get workspace name
function getWorkspaceName(workspaceId) {
    const names = {
        'mission-control': 'Centrum Dowodzenia',
        'data-lab': 'Laboratorium Danych',
        'creative-studio': 'Studio Kreatywne'
    };
    return names[workspaceId] || workspaceId;
}

// Agent Filtering
function filterAgents(filter) {
    AppState.agentFilter = filter;
    
    // Update filter buttons
    Elements.filterBtns.forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.filter === filter) {
            btn.classList.add('active');
        }
    });

    // Filter agent orbs
    Elements.agentOrbs.forEach(orb => {
        const tier = orb.dataset.tier;
        
        if (filter === 'all' || tier === filter) {
            orb.style.display = 'block';
            orb.style.opacity = '0';
            orb.style.transform = 'scale(0.8)';
            
            setTimeout(() => {
                orb.style.transition = 'all 0.5s cubic-bezier(0.16, 1, 0.3, 1)';
                orb.style.opacity = '1';
                orb.style.transform = 'scale(1)';
            }, 100);
        } else {
            orb.style.opacity = '0';
            orb.style.transform = 'scale(0.8)';
            setTimeout(() => {
                orb.style.display = 'none';
            }, 500);
        }
    });

    // Voice feedback
    const filterNames = {
        'all': 'wszystkie agenty',
        'free': 'darmowe agenty',
        'premium': 'premium agenty'
    };
    speak(`Filtrowanie: ${filterNames[filter]}`);
}

// Agent Activation
function activateAgent(agentId) {
    const orb = document.querySelector(`[data-agent="${agentId}"]`);
    if (orb) {
        // Visual feedback
        orb.style.transform = 'translateY(-10px) scale(1.1)';
        orb.style.boxShadow = '0 20px 60px rgba(50, 184, 198, 0.8)';
        
        // Pulse animation
        const core = orb.querySelector('.orb-core');
        if (core) {
            core.style.animation = 'pulse 0.5s ease-in-out 3';
        }

        // Reset after animation
        setTimeout(() => {
            orb.style.transform = 'translateY(0) scale(1)';
            orb.style.boxShadow = '';
            if (core) {
                core.style.animation = '';
            }
        }, 1500);

        // Voice feedback
        const agentName = orb.querySelector('h4').textContent;
        speak(`Aktywowano agenta: ${agentName}`);
        
        console.log(`🤖 Aktywowano agenta: ${agentName}`);
    }
}

// Start Real-time Updates
function startRealTimeUpdates() {
    // Simulate real-time data updates
    updatePerformanceMetrics();
    updateDataStreams();
    updateAgentActivity();
    updateSystemHealth();
    
    // Continue updates every 5 seconds
    setInterval(() => {
        updatePerformanceMetrics();
        updateDataStreams();
        updateAgentActivity();
        updateSystemHealth();
    }, 5000);
}

// Update Performance Metrics
function updatePerformanceMetrics() {
    const metric = document.querySelector('.performance-galaxy .metric-value');
    if (metric) {
        const uptime = (98 + Math.random() * 2).toFixed(1);
        metric.textContent = `${uptime}% Uptime`;
    }
}

// Update Data Streams
function updateDataStreams() {
    const metric = document.querySelector('.data-streams .metric-value');
    if (metric) {
        const requests = (2000 + Math.random() * 1000).toFixed(0);
        metric.textContent = `${requests} req/min`;
    }
}

// Update Agent Activity
function updateAgentActivity() {
    const metric = document.querySelector('.agent-activity .metric-value');
    if (metric) {
        const active = Math.floor(5 + Math.random() * 5);
        metric.textContent = `${active} aktywnych`;
    }
}

// Update System Health
function updateSystemHealth() {
    const metric = document.querySelector('.system-health .metric-value');
    const core = document.querySelector('.health-core');
    
    if (metric && core) {
        const healthStates = [
            { text: 'Optimal', class: 'status--success', color: 'var(--color-success)' },
            { text: 'Good', class: 'status--info', color: 'var(--color-info)' },
            { text: 'Warning', class: 'status--warning', color: 'var(--color-warning)' }
        ];
        
        const randomState = healthStates[Math.floor(Math.random() * healthStates.length)];
        metric.textContent = randomState.text;
        metric.className = `metric-value ${randomState.class}`;
    }
}

// Keyboard Navigation
function handleKeyboardNavigation(event) {
    const { key, ctrlKey, altKey } = event;
    
    if (altKey) {
        switch(key) {
            case '1':
                navigateToSection('workspaces');
                break;
            case '2':
                navigateToSection('agents');
                break;
            case '3':
                navigateToSection('monitor');
                break;
            case '4':
                navigateToSection('collaboration');
                break;
            case 'v':
                toggleVoiceInterface();
                break;
        }
        event.preventDefault();
    }
    
    if (key === 'Escape') {
        if (AppState.voiceActive) {
            toggleVoiceInterface();
        }
    }
}

// Handle Window Resize
function handleResize() {
    // Adjust layouts for mobile
    const isMobile = window.innerWidth <= 768;
    
    if (isMobile) {
        // Simplify animations for mobile
        document.documentElement.style.setProperty('--animation-duration', '0.3s');
    } else {
        document.documentElement.style.setProperty('--animation-duration', '0.6s');
    }
}

// Start Background Animations
function startAnimations() {
    // Continuous particle animations
    animateParticles();
    
    // Floating elements
    animateFloatingElements();
    
    // Orbital movements
    animateOrbitalElements();
}

// Animate Particles
function animateParticles() {
    const particles = document.querySelectorAll('.data-particle');
    particles.forEach((particle, index) => {
        setInterval(() => {
            particle.style.transform = `translateY(${Math.random() * 200 - 100}px) translateX(${Math.random() * 50 - 25}px)`;
        }, 3000 + index * 500);
    });
}

// Animate Floating Elements
function animateFloatingElements() {
    const floatingElements = document.querySelectorAll('.orb-core, .galaxy-center, .health-core');
    
    floatingElements.forEach((element, index) => {
        let direction = 1;
        setInterval(() => {
            direction *= -1;
            element.style.transform += ` translateY(${direction * 2}px)`;
        }, 2000 + index * 300);
    });
}

// Animate Orbital Elements
function animateOrbitalElements() {
    const orbitalElements = document.querySelectorAll('.element--orbit, .timeline-point');
    
    orbitalElements.forEach((element, index) => {
        element.style.animationDelay = `${-index * 2}s`;
    });
}

// Utility Functions
function getRandomFloat(min, max) {
    return Math.random() * (max - min) + min;
}

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Export for global access
window.FuturisticApp = {
    navigateToSection,
    selectWorkspace,
    filterAgents,
    activateAgent,
    toggleVoiceInterface,
    speak
};

// Performance monitoring
if ('performance' in window) {
    window.addEventListener('load', () => {
        setTimeout(() => {
            const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
            console.log(`⚡ Aplikacja załadowana w ${loadTime}ms`);
        }, 0);
    });
}